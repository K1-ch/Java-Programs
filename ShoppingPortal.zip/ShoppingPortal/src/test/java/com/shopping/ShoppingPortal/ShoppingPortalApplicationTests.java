package com.shopping.ShoppingPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
